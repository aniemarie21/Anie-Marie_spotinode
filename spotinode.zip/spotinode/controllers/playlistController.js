const db = require('../config/db');

// Create playlist
exports.createPlaylist = (req, res) => {
    const { name } = req.body;
    db.query('INSERT INTO playlists (name) VALUES (?)', [name], (err, result) => {
        if (err) throw err;
        res.json({ message: 'Playlist created successfully' });
    });
};

// Add song to playlist
exports.addSongToPlaylist = (req, res) => {
    const { playlistId, songId } = req.body;
    db.query('INSERT INTO playlist_songs (playlist_id, song_id) VALUES (?, ?)', [playlistId, songId], (err, result) => {
        if (err) throw err;
        res.json({ message: 'Song added to playlist' });
    });
};

// Get all playlists
exports.getAllPlaylists = (req, res) => {
    db.query('SELECT * FROM playlists', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
};
