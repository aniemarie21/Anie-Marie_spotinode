const path = require('path');
const db = require('../config/db');

// Upload song
exports.uploadSong = (req, res) => {
    const file = req.files.song;
    const filename = file.name;
    const filePath = path.join(__dirname, '../public/uploads/', filename);

    // Move song file to uploads directory
    file.mv(filePath, err => {
        if (err) {
            return res.status(500).send(err);
        }

        // Save song details in the database
        db.query('INSERT INTO songs (title, file) VALUES (?, ?)', [filename, filename], (err, result) => {
            if (err) throw err;
            res.json({ message: 'Song uploaded successfully' });
        });
    });
};

// Fetch all songs
exports.getAllSongs = (req, res) => {
    db.query('SELECT * FROM songs', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
};
