const express = require('express');
const router = express.Router();
const db = require('../config/db');
const path = require('path');

// Upload song route
router.post('/upload', (req, res) => {
    // Check if files were uploaded
    if (!req.files || Object.keys(req.files).length === 0) {
        return res.status(400).json({ error: 'No files were uploaded.' });
    }

    const songFile = req.files.song; // Get the uploaded file
    const uploadPath = path.join(__dirname, '../public/uploads/', songFile.name);

    // Move the file to the uploads directory
    songFile.mv(uploadPath, (err) => {
        if (err) {
            console.error('Error moving file:', err);
            return res.status(500).json({ error: 'Failed to upload file.' });
        }

        // Save the song information to the database
        const songTitle = req.body.title; // Get song title from the form
        const songArtist = req.body.artist; // Get artist from the form
        db.query('INSERT INTO songs (title, file, artist) VALUES (?, ?, ?)', [songTitle, songFile.name, songArtist], (err, result) => {
            if (err) {
                console.error('Database error while inserting song:', err);
                return res.status(500).json({ error: 'Failed to save song information.' });
            }

            // Send back a success message
            res.json({ message: 'Song uploaded successfully!' });
        });
    });
});

// Add song to playlist route
router.post('/add-to-playlist', (req, res) => {
    const { playlistId, songId } = req.body;

    // Validate input
    if (!playlistId || !songId) {
        return res.status(400).json({ error: 'Playlist ID and Song ID are required.' });
    }

    db.query('INSERT INTO playlist_songs (playlist_id, song_id) VALUES (?, ?)', [playlistId, songId], (err, result) => {
        if (err) {
            console.error('Error adding song to playlist:', err);
            return res.status(500).json({ error: 'Failed to add song to playlist.' });
        }
        res.json({ message: 'Song added to playlist successfully!' });
    });
});

// Fetch all songs route
router.get('/', (req, res) => {
    db.query('SELECT * FROM songs', (err, results) => {
        if (err) {
            console.error('Database error while fetching songs:', err);
            return res.status(500).json({ error: 'Database error while fetching songs.' });
        }

        // Send the song data as JSON
        res.json(results);
    });
});

// Fetch playlists route
router.get('/playlists', (req, res) => {
    db.query('SELECT * FROM playlists', (err, results) => {
        if (err) {
            console.error('Database error while fetching playlists:', err);
            return res.status(500).json({ error: 'Database error while fetching playlists.' });
        }
        res.json(results);
    });
});

module.exports = router;
