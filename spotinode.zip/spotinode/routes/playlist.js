const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Create playlist route
router.post('/create', (req, res) => {
    const { name } = req.body;

    db.query('INSERT INTO playlists (name) VALUES (?)', [name], (err, result) => {
        if (err) {
            console.error('Error creating playlist:', err);
            return res.status(500).json({ error: 'Failed to create playlist' });
        }
        res.json({ message: 'Playlist created successfully!' });
    });
});

// Get all playlists route
router.get('/', (req, res) => {
    db.query('SELECT * FROM playlists', (err, results) => {
        if (err) {
            console.error('Error fetching playlists:', err);
            return res.status(500).json({ error: 'Failed to fetch playlists' });
        }
        res.json(results);
    });
});

// Get songs in a specific playlist route
router.get('/:playlistId/songs', (req, res) => {
    const { playlistId } = req.params;

    db.query('SELECT songs.* FROM songs JOIN playlist_songs ON songs.id = playlist_songs.song_id WHERE playlist_songs.playlist_id = ?', [playlistId], (err, results) => {
        if (err) {
            console.error('Error fetching songs in playlist:', err);
            return res.status(500).json({ error: 'Failed to fetch songs in playlist' });
        }
        res.json(results);
    });
});

// Add song to playlist route
router.post('/add-to-playlist', (req, res) => {
    const { playlistId, songId } = req.body;

    db.query('INSERT INTO playlist_songs (playlist_id, song_id) VALUES (?, ?)', [playlistId, songId], (err, result) => {
        if (err) {
            console.error('Error adding song to playlist:', err);
            return res.status(500).json({ error: 'Failed to add song to playlist' });
        }
        res.json({ message: 'Song added to playlist successfully!' });
    });
});

module.exports = router;
