const express = require('express');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const authRoutes = require('./routes/auth');
const songRoutes = require('./routes/song');
const playlistRoutes = require('./routes/playlist');
const path = require('path');

const app = express();
const PORT = 3002;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(fileUpload());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Route for the homepage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Use routes
app.use('/auth', authRoutes);
app.use('/songs', songRoutes);
app.use('/playlists', playlistRoutes);

// Start the server
app.listen(3003, () => {
    console.log(`SpotiNode running on http://localhost:${3003}`);
});
