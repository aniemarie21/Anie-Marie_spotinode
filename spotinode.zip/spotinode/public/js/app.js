document.addEventListener('DOMContentLoaded', () => {
    // Fetch songs from the server
    fetch('/songs')
        .then(response => response.json())
        .then(songs => {
            const songsList = document.getElementById('songs-list');
            songsList.innerHTML = ''; // Clear any existing list

            songs.forEach(song => {
                const listItem = document.createElement('li');
                listItem.setAttribute('data-id', song.id); // Set the data-id attribute for the song ID

                // Create song title and artist elements
                const songInfo = document.createElement('p');
                songInfo.innerText = `${song.title} by ${song.artist}`;

                // Create audio player
                const audioPlayer = document.createElement('audio');
                audioPlayer.controls = true;
                audioPlayer.src = `/uploads/${song.file}`; // Path to the uploaded song file

                // Create button to add song to playlist
                const addToPlaylistButton = document.createElement('button');
                addToPlaylistButton.innerText = 'Add to Playlist';
                addToPlaylistButton.classList.add('btn-action', 'btn-add-to-playlist'); // Apply styles
                addToPlaylistButton.onclick = () => {
                    const playlistId = prompt('Enter Playlist ID to add this song:');
                    if (!playlistId) {
                        alert('Playlist ID is required!');
                        return;
                    }

                    console.log(`Adding song ID: ${song.id} to playlist ID: ${playlistId}`); // Log for debugging

                    fetch('/songs/add-to-playlist', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ playlistId, songId: song.id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            alert(`Error: ${data.error}`); // Alert the user if there's an error
                        } else {
                            alert(data.message); // Show success message
                        }
                    })
                    .catch(error => {
                        console.error('Error adding song to playlist:', error);
                        alert('An error occurred while adding the song to the playlist.');
                    });
                };

                // Create delete button
                const deleteButton = document.createElement('button');
                deleteButton.innerText = 'Delete';
                deleteButton.classList.add('btn-action', 'btn-delete'); // Apply styles
                deleteButton.onclick = (event) => {
                    event.stopPropagation(); // Prevent event bubbling
                    deleteSong(deleteButton); // Call the deleteSong function
                };

                // Append song info, audio player, and buttons to the list item
                listItem.appendChild(songInfo);
                listItem.appendChild(audioPlayer);
                listItem.appendChild(addToPlaylistButton);
                listItem.appendChild(deleteButton);

                // Append list item to the songs list
                songsList.appendChild(listItem);
            });
        })
        .catch(error => {
            console.error('Error fetching songs:', error);
            alert('An error occurred while fetching songs.');
        });

    // Search functionality
    document.getElementById('search-songs').addEventListener('input', filterSongs);

    // Handle the create playlist form submission
    document.getElementById('create-playlist-form').addEventListener('submit', (event) => {
        event.preventDefault(); // Prevent form submission

        const playlistName = document.getElementById('playlist-name').value.trim();
        if (!playlistName) {
            alert('Playlist name is required!');
            return;
        }

        fetch('/playlists/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: playlistName })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message); // Show success message
            document.getElementById('playlist-name').value = ''; // Clear input
            loadPlaylists(); // Reload playlists
        })
        .catch(error => {
            console.error('Error creating playlist:', error);
            alert('An error occurred while creating the playlist.');
        });
    });

    // Load playlists from the server
    loadPlaylists();
});

// Load playlists function
function loadPlaylists() {
    fetch('/playlists')
        .then(response => response.json())
        .then(playlists => {
            const playlistsList = document.getElementById('playlists-list');
            playlistsList.innerHTML = ''; // Clear existing playlists

            playlists.forEach(playlist => {
                const listItem = document.createElement('li');
                listItem.innerText = playlist.name; // Display playlist name
                playlistsList.appendChild(listItem);

                // Add button to view songs in the playlist
                const viewSongsButton = document.createElement('button');
                viewSongsButton.innerText = 'View Songs';
                viewSongsButton.onclick = () => loadPlaylistSongs(playlist.id);
                listItem.appendChild(viewSongsButton); // Append button to list item
            });
        })
        .catch(error => {
            console.error('Error fetching playlists:', error);
            alert('An error occurred while fetching playlists.');
        });
}

// Function to load songs in a selected playlist
function loadPlaylistSongs(playlistId) {
    fetch(`/playlists/${playlistId}/songs`)
        .then(response => response.json())
        .then(songs => {
            const playlistSongsList = document.getElementById('playlist-songs');
            playlistSongsList.innerHTML = ''; // Clear existing songs

            songs.forEach(song => {
                const listItem = document.createElement('li');
                listItem.innerText = `${song.title} by ${song.artist}`; // Display song title and artist

                // Create remove button
                const removeButton = document.createElement('button');
                removeButton.innerText = 'Remove';
                removeButton.classList.add('btn-remove');
                removeButton.onclick = () => {
                    const confirmation = confirm(`Are you sure you want to remove "${song.title}" from the playlist?`);
                    if (confirmation) {
                        fetch(`/playlists/${playlistId}/remove`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ songId: song.id })
                        })
                        .then(response => response.json())
                        .then(data => {
                            alert(data.message); // Show success message
                            loadPlaylistSongs(playlistId); // Refresh the playlist
                        })
                        .catch(error => {
                            console.error('Error removing song:', error);
                            alert('An error occurred while removing the song.');
                        });
                    }
                };

                // Append song and remove button to the list item
                listItem.appendChild(removeButton);
                playlistSongsList.appendChild(listItem); // Append song to the playlist songs list
            });
        })
        .catch(error => {
            console.error('Error fetching playlist songs:', error);
            alert('An error occurred while fetching songs in the playlist.');
        });
}

// Search songs function
function filterSongs() {
    const searchInput = document.getElementById("search-songs").value.toLowerCase();
    const songItems = document.querySelectorAll("#songs-list li");

    songItems.forEach(song => {
        const songTitle = song.querySelector('p').textContent.toLowerCase(); // Get title from paragraph
        if (songTitle.includes(searchInput)) {
            song.style.display = ""; // Show the song if it matches the search
        } else {
            song.style.display = "none"; // Hide the song if it doesn't match
        }
    });
}


