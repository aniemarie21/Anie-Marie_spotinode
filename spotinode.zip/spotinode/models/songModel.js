const db = require('../config/db');

// Create a new song
exports.createSong = (title, file, callback) => {
    db.query('INSERT INTO songs (title, file) VALUES (?, ?)', [title, file], (err, result) => {
        if (err) {
            console.error('Error creating song:', err);
            return callback(err, null);
        }
        callback(null, result);
    });
};

// Get all songs
exports.getAllSongs = callback => {
    db.query('SELECT * FROM songs', (err, results) => {
        if (err) {
            console.error('Error fetching songs:', err);
            return callback(err, null);
        }
        callback(null, results);
    });
};

// Get a song by ID
exports.getSongById = (songId, callback) => {
    db.query('SELECT * FROM songs WHERE id = ?', [songId], (err, result) => {
        if (err) {
            console.error('Error fetching song by ID:', err);
            return callback(err, null);
        }
        callback(null, result);
    });
};

// Update song details
exports.updateSong = (songId, title, file, callback) => {
    db.query('UPDATE songs SET title = ?, file = ? WHERE id = ?', [title, file, songId], (err, result) => {
        if (err) {
            console.error('Error updating song:', err);
            return callback(err, null);
        }
        callback(null, result);
    });
};

// Delete a song
exports.deleteSong = (songId, callback) => {
    db.query('DELETE FROM songs WHERE id = ?', [songId], (err, result) => {
        if (err) {
            console.error('Error deleting song:', err);
            return callback(err, null);
        }
        callback(null, result);
    });
};
